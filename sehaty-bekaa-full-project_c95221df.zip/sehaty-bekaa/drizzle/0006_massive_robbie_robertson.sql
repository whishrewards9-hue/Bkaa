ALTER TABLE `patient_files` ADD `appointmentId` int;--> statement-breakpoint
CREATE INDEX `file_appointment_idx` ON `patient_files` (`appointmentId`);