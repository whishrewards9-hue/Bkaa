ALTER TABLE `password_reset_otps` ADD `purpose` varchar(32) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `phoneVerified` boolean DEFAULT false NOT NULL;