CREATE TABLE `email_password_reset_otps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`consumed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `email_password_reset_otps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `email_password_reset_otp_idx` ON `email_password_reset_otps` (`email`,`createdAt`);