CREATE TABLE `clinic_closures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctorId` int NOT NULL,
	`closureDate` varchar(10) NOT NULL,
	`startTime` varchar(5),
	`endTime` varchar(5),
	`note` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clinic_closures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `closure_doctor_date_idx` ON `clinic_closures` (`doctorId`,`closureDate`);--> statement-breakpoint
CREATE INDEX `closure_date_idx` ON `clinic_closures` (`closureDate`);