CREATE TABLE `favorite_doctors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`doctorId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `favorite_doctors_id` PRIMARY KEY(`id`),
	CONSTRAINT `favorite_user_doctor_unique` UNIQUE(`userId`,`doctorId`)
);
--> statement-breakpoint
CREATE INDEX `favorite_user_idx` ON `favorite_doctors` (`userId`);--> statement-breakpoint
CREATE INDEX `favorite_doctor_idx` ON `favorite_doctors` (`doctorId`);