ALTER TABLE `doctors` ADD `customSpecialty` varchar(160);--> statement-breakpoint
ALTER TABLE `doctors` ADD `clinicName` varchar(180);--> statement-breakpoint
ALTER TABLE `doctors` ADD `clinicAddress` varchar(300);--> statement-breakpoint
ALTER TABLE `doctors` ADD `clinicLocationUrl` varchar(700);--> statement-breakpoint
ALTER TABLE `doctors` ADD `photoUrl` varchar(700);