CREATE TABLE `password_reset_otps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phone` varchar(40) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`consumed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `password_reset_otps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `password_reset_otp_phone_idx` ON `password_reset_otps` (`phone`,`createdAt`);