CREATE TABLE `appointments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`doctorId` int NOT NULL,
	`appointmentDate` varchar(10) NOT NULL,
	`appointmentTime` varchar(5) NOT NULL,
	`appointmentStatus` enum('pending','confirmed','declined','cancelled','rescheduled') NOT NULL DEFAULT 'pending',
	`patientNote` text,
	`doctorNote` text,
	`proposedDate` varchar(10),
	`proposedTime` varchar(5),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appointments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `doctors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`fullName` varchar(160) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`specialtyId` int NOT NULL,
	`hospitalId` int,
	`bio` text,
	`accessCodeHash` varchar(255),
	`scheduleStart` varchar(5) NOT NULL DEFAULT '09:00',
	`scheduleEnd` varchar(5) NOT NULL DEFAULT '17:00',
	`slotMinutes` int NOT NULL DEFAULT 10,
	`availabilityDays` varchar(80) NOT NULL DEFAULT '1,2,3,4,5',
	`blockedDates` text,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `doctors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hospitals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`area` varchar(120) NOT NULL,
	`phone` varchar(80) NOT NULL,
	`website` varchar(500),
	`sourceUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `hospitals_id` PRIMARY KEY(`id`),
	CONSTRAINT `hospital_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `medical_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`doctorId` int NOT NULL,
	`appointmentId` int,
	`diagnosis` text,
	`medications` text,
	`tests` text,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `medical_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientUserId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`kind` varchar(48) NOT NULL DEFAULT 'general',
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patient_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`recordId` int,
	`originalName` varchar(255) NOT NULL,
	`mimeType` varchar(100) NOT NULL,
	`fileKey` varchar(600) NOT NULL,
	`url` varchar(700) NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `patient_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patient_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fullName` varchar(160) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`birthDate` varchar(10),
	`gender` enum('male','female','unspecified') NOT NULL DEFAULT 'unspecified',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patient_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `patient_profile_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `specialties` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`icon` varchar(48) NOT NULL DEFAULT 'Stethoscope',
	`description` text,
	`imageUrl` varchar(500),
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `specialties_id` PRIMARY KEY(`id`),
	CONSTRAINT `specialty_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','doctor','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
CREATE INDEX `appointment_doctor_slot_idx` ON `appointments` (`doctorId`,`appointmentDate`,`appointmentTime`);--> statement-breakpoint
CREATE INDEX `appointment_patient_idx` ON `appointments` (`patientId`);--> statement-breakpoint
CREATE INDEX `doctor_specialty_idx` ON `doctors` (`specialtyId`);--> statement-breakpoint
CREATE INDEX `doctor_user_idx` ON `doctors` (`userId`);--> statement-breakpoint
CREATE INDEX `record_patient_idx` ON `medical_records` (`patientId`);--> statement-breakpoint
CREATE INDEX `record_appointment_idx` ON `medical_records` (`appointmentId`);--> statement-breakpoint
CREATE INDEX `notification_recipient_idx` ON `notifications` (`recipientUserId`,`read`);--> statement-breakpoint
CREATE INDEX `file_patient_idx` ON `patient_files` (`patientId`);--> statement-breakpoint
CREATE INDEX `file_record_idx` ON `patient_files` (`recordId`);