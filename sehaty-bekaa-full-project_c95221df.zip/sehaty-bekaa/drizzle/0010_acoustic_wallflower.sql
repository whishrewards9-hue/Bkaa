CREATE INDEX `appointment_doctor_date_status_idx` ON `appointments` (`doctorId`,`appointmentDate`,`appointmentStatus`);--> statement-breakpoint
CREATE INDEX `appointment_patient_date_idx` ON `appointments` (`patientId`,`appointmentDate`,`appointmentTime`);--> statement-breakpoint
CREATE INDEX `record_patient_created_idx` ON `medical_records` (`patientId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `notification_recipient_created_idx` ON `notifications` (`recipientUserId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `file_patient_uploaded_idx` ON `patient_files` (`patientId`,`uploadedAt`);