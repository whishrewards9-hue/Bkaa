import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core identity record populated by Manus OAuth. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }).notNull().unique(),
    name: text("name"),
    email: varchar("email", { length: 320 }),
    phone: varchar("phone", { length: 40 }).unique(),
    passwordHash: varchar("passwordHash", { length: 255 }),
    phoneVerified: boolean("phoneVerified").notNull().default(false),
    loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "doctor", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const specialties = mysqlTable(
  "specialties",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    icon: varchar("icon", { length: 48 }).notNull().default("Stethoscope"),
    description: text("description"),
    imageUrl: varchar("imageUrl", { length: 500 }),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("specialty_name_unique").on(table.name)],
);

export const hospitals = mysqlTable(
  "hospitals",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 180 }).notNull(),
    area: varchar("area", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 80 }).notNull(),
    website: varchar("website", { length: 500 }),
    sourceUrl: varchar("sourceUrl", { length: 500 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("hospital_name_unique").on(table.name)],
);

export const patientProfiles = mysqlTable(
  "patient_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    fullName: varchar("fullName", { length: 160 }).notNull(),
    phone: varchar("phone", { length: 40 }).notNull(),
    birthDate: varchar("birthDate", { length: 10 }),
    gender: mysqlEnum("gender", ["male", "female", "unspecified"]).default("unspecified").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("patient_profile_user_unique").on(table.userId)],
);

export const doctors = mysqlTable(
  "doctors",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId"),
    fullName: varchar("fullName", { length: 160 }).notNull(),
    phone: varchar("phone", { length: 40 }).notNull(),
    specialtyId: int("specialtyId").notNull(),
    customSpecialty: varchar("customSpecialty", { length: 160 }),
    hospitalId: int("hospitalId"),
    clinicName: varchar("clinicName", { length: 180 }),
    clinicAddress: varchar("clinicAddress", { length: 300 }),
    clinicLocationUrl: varchar("clinicLocationUrl", { length: 700 }),
    photoUrl: varchar("photoUrl", { length: 700 }),
    bio: text("bio"),
    accessCodeHash: varchar("accessCodeHash", { length: 255 }),
    scheduleStart: varchar("scheduleStart", { length: 5 }).notNull().default("09:00"),
    scheduleEnd: varchar("scheduleEnd", { length: 5 }).notNull().default("17:00"),
    slotMinutes: int("slotMinutes").notNull().default(10),
    availabilityDays: varchar("availabilityDays", { length: 80 }).notNull().default("1,2,3,4,5"),
    blockedDates: text("blockedDates"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("doctor_specialty_idx").on(table.specialtyId), index("doctor_user_idx").on(table.userId)],
);

export const favoriteDoctors = mysqlTable(
  "favorite_doctors",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    doctorId: int("doctorId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("favorite_user_doctor_unique").on(table.userId, table.doctorId), index("favorite_user_idx").on(table.userId), index("favorite_doctor_idx").on(table.doctorId)],
);

export const clinicClosures = mysqlTable(
  "clinic_closures",
  {
    id: int("id").autoincrement().primaryKey(),
    doctorId: int("doctorId").notNull(),
    closureDate: varchar("closureDate", { length: 10 }).notNull(),
    startTime: varchar("startTime", { length: 5 }),
    endTime: varchar("endTime", { length: 5 }),
    note: varchar("note", { length: 500 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("closure_doctor_date_idx").on(table.doctorId, table.closureDate), index("closure_date_idx").on(table.closureDate)],
);

export const appointments = mysqlTable(
  "appointments",
  {
    id: int("id").autoincrement().primaryKey(),
    patientId: int("patientId").notNull(),
    doctorId: int("doctorId").notNull(),
    appointmentDate: varchar("appointmentDate", { length: 10 }).notNull(),
    appointmentTime: varchar("appointmentTime", { length: 5 }).notNull(),
    status: mysqlEnum("appointmentStatus", ["pending", "confirmed", "declined", "cancelled", "rescheduled"])
      .notNull()
      .default("pending"),
    patientNote: text("patientNote"),
    doctorNote: text("doctorNote"),
    proposedDate: varchar("proposedDate", { length: 10 }),
    proposedTime: varchar("proposedTime", { length: 5 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("appointment_doctor_slot_idx").on(table.doctorId, table.appointmentDate, table.appointmentTime),
    index("appointment_doctor_date_status_idx").on(table.doctorId, table.appointmentDate, table.status),
    index("appointment_patient_idx").on(table.patientId),
    index("appointment_patient_date_idx").on(table.patientId, table.appointmentDate, table.appointmentTime),
  ],
);

export const medicalRecords = mysqlTable(
  "medical_records",
  {
    id: int("id").autoincrement().primaryKey(),
    patientId: int("patientId").notNull(),
    doctorId: int("doctorId").notNull(),
    appointmentId: int("appointmentId"),
    diagnosis: text("diagnosis"),
    medications: text("medications"),
    tests: text("tests"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("record_patient_idx").on(table.patientId), index("record_patient_created_idx").on(table.patientId, table.createdAt), index("record_appointment_idx").on(table.appointmentId)],
);

export const patientFiles = mysqlTable(
  "patient_files",
  {
    id: int("id").autoincrement().primaryKey(),
    patientId: int("patientId").notNull(),
    appointmentId: int("appointmentId"),
    recordId: int("recordId"),
    originalName: varchar("originalName", { length: 255 }).notNull(),
    mimeType: varchar("mimeType", { length: 100 }).notNull(),
    fileKey: varchar("fileKey", { length: 600 }).notNull(),
    url: varchar("url", { length: 700 }).notNull(),
    uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  },
  table => [index("file_patient_idx").on(table.patientId), index("file_patient_uploaded_idx").on(table.patientId, table.uploadedAt), index("file_appointment_idx").on(table.appointmentId), index("file_record_idx").on(table.recordId)],
);

export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    recipientUserId: int("recipientUserId").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    kind: varchar("kind", { length: 48 }).notNull().default("general"),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("notification_recipient_idx").on(table.recipientUserId, table.read), index("notification_recipient_created_idx").on(table.recipientUserId, table.createdAt)],
);

export const passwordResetOtps = mysqlTable(
  "password_reset_otps",
  {
    id: int("id").autoincrement().primaryKey(),
    phone: varchar("phone", { length: 40 }).notNull(),
    purpose: varchar("purpose", { length: 32 }).notNull(),
    codeHash: varchar("codeHash", { length: 128 }).notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    attempts: int("attempts").notNull().default(0),
    consumed: boolean("consumed").notNull().default(false),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("password_reset_otp_phone_idx").on(table.phone, table.createdAt)],
);

export const emailPasswordResetOtps = mysqlTable(
  "email_password_reset_otps",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    codeHash: varchar("codeHash", { length: 128 }).notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    attempts: int("attempts").notNull().default(0),
    consumed: boolean("consumed").notNull().default(false),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("email_password_reset_otp_idx").on(table.email, table.createdAt)],
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
