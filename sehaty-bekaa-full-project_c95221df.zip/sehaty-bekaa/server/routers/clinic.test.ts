import { describe, expect, it } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

function createPatientContext(): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "patient-test",
      email: "patient@example.com",
      name: "Patient Test",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("clinic router safeguards", () => {
  it("rejects malformed appointment dates before any booking is created", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.patient.book({
      doctorId: 1,
      appointmentDate: "2026/01/01",
      appointmentTime: "10:00",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects invalid booking times before any booking is created", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.patient.book({
      doctorId: 1,
      appointmentDate: "2026-01-01",
      appointmentTime: "ten",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("prevents ordinary patient accounts from reading administrative summary data", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.admin.summary()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("keeps the patient profile flow unavailable to doctor accounts", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "doctor" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.patient.profile()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("keeps favorite doctors restricted to patient accounts", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "doctor" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.patient.favorites()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("validates a favorite doctor id before changing the list", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.patient.toggleFavorite({ doctorId: 0 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("keeps doctor appointment controls unavailable to patient accounts", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.doctor.appointments()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("protects the admin gate from patient accounts and wrong codes", async () => {
    const patientCaller = appRouter.createCaller(createPatientContext());
    await expect(patientCaller.clinic.admin.verifyAccess({ accessCode: "hb1519980" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    const adminContext = createPatientContext();
    adminContext.user = { ...adminContext.user, role: "admin" };
    const adminCaller = appRouter.createCaller(adminContext);
    await expect(adminCaller.clinic.admin.verifyAccess({ accessCode: "wrong-code" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires a valid requested appointment status from doctors", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "doctor" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.doctor.updateAppointment({
      appointmentId: 1,
      status: "pending" as never,
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("requires at least one clinic day when saving a doctor schedule", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "doctor" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.doctor.updateSchedule({ scheduleStart: "09:00", scheduleEnd: "17:00", availabilityDays: "" as never, blockedDates: [] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("requires at least one date when creating a temporary clinic closure", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "doctor" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.doctor.createClosure({ dates: [] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("validates the monthly availability input before querying the database", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.patient.monthAvailability({ doctorId: 1, month: "2026/09" as never })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("keeps patient password reset restricted to administrators", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.admin.resetPatientPassword({ phone: "03123456", newPassword: "new-password-123" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("keeps doctor profile photo uploads restricted to administrators", async () => {
    const caller = appRouter.createCaller(createPatientContext());
    await expect(caller.clinic.admin.uploadDoctorPhoto({ doctorId: 1, originalName: "doctor.jpg", mimeType: "image/jpeg", dataUrl: "data:image/jpeg;base64,AA==" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("validates doctor clinic location links before saving the profile", async () => {
    const context = createPatientContext();
    context.user = { ...context.user, role: "admin" };
    const caller = appRouter.createCaller(context);
    await expect(caller.clinic.admin.updateDoctor({
      id: 1,
      fullName: "د. اختبار",
      phone: "03123456",
      specialtyId: 1,
      clinicLocationUrl: "not-a-url",
      scheduleStart: "09:00",
      scheduleEnd: "17:00",
      slotMinutes: 30,
      availabilityDays: "1,2,3",
      blockedDates: [],
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
