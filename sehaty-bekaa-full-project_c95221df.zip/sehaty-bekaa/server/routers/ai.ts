import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { protectedProcedure, router } from "../_core/trpc";
import { listDoctors, listHospitals } from "../db";

const scopeKeywords = /مستشفى|مشفى|طبيب|دكتور|حكيم|اختصاص|رقم|هاتف|اتصال|عيادة|دوام|حجز|موعد|بقاع|بيروت|المركز|مركز/i;
const guidance = `أنت مساعد دليل صحي محدود ضمن منصة صحتي البقاع. أجب بالعربية الفصحى وباختصار. نطاقك المسموح حصراً هو: البحث في دليل المستشفيات والأطباء، أرقام الهاتف، المناطق، الاختصاصات، أوقات العيادة المحفوظة، وطريقة حجز موعد داخل المنصة. إذا كان السؤال خارج هذا النطاق، اعتذر وقل إنك مخصص لدليل الأطباء والمستشفيات والحجوزات فقط. لا تشخّص، ولا تفسر أمراضاً، ولا تقدم نصائح أو جرعات أدوية أو نتائج فحوصات. لا تخترع أي اسم أو رقم أو ساعة؛ استخدم الدليل المرفق فقط. إذا لم تجد الجهة في الدليل، قل إن بياناتها غير متوفرة ووجّه المستخدم إلى صفحة الدليل. عند الطوارئ، اذكر الاتصال بالطوارئ فوراً دون تشخيص.`;

export const aiRouter = router({
  chat: protectedProcedure.input(z.object({
    messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(1000) })).min(1).max(12),
  })).mutation(async ({ input }) => {
    const latest = input.messages[input.messages.length - 1]?.content || "";
    if (!scopeKeywords.test(latest)) return { answer: "أنا مخصص فقط لدليل الأطباء والمستشفيات وأرقام التواصل والاختصاصات وأوقات العيادات وطريقة حجز الموعد داخل المنصة." };
    const [hospitals, doctors] = await Promise.all([listHospitals(), listDoctors()]);
    const directoryContext = `دليل موثّق داخل المنصة — لا تخترع رقماً: المستشفيات: ${hospitals.slice(0, 30).map(item => `${item.name} (${item.area}): ${item.phone}`).join("؛ ")}. الأطباء: ${doctors.slice(0, 30).map(item => `${item.fullName} (${item.specialtyName}): ${item.phone}، الدوام ${item.scheduleStart}-${item.scheduleEnd}`).join("؛ ")}.`;
    const response = await invokeLLM({ messages: [{ role: "system", content: `${guidance}\n${directoryContext}` }, ...input.messages], max_tokens: 350 });
    const content = response.choices[0]?.message.content;
    const answer = typeof content === "string" ? content : content?.map(part => part.type === "text" ? part.text : "").join("") || "تعذر إنشاء إجابة الآن؛ يرجى المحاولة لاحقاً.";
    return { answer };
  }),
});
