import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  addDoctor,
  cancelPatientAppointment,
  closeDoctorDate,
  createDoctorClosure,
  claimDoctorProfile,
  createAppointment,
  createMedicalRecord,
  changeDoctorAccessCode,
  deleteDoctor,
  getAdminSummary,
  getDoctorForUser,
  getPatientProfile,
  listDoctorAppointments,
  listDoctorClosures,
  listDoctorAppointmentFiles,
  listFavoriteDoctors,
  listDoctors,
  listHospitals,
  listNotifications,
  listPatientAppointments,
  listDoctorMonthAvailability,
  listPatientSlotAvailability,
  listPatientFiles,
  listPatientRecords,
  listSpecialties,
  markNotificationRead,
  savePatientProfile,
  updateDoctor,
  uploadDoctorPhoto,
  updateDoctorAppointment,
  updateDoctorSchedule,
  toggleFavoriteDoctor,
  uploadPatientFile,
  deleteOldPatientAppointments,
  deletePatientAppointment,
  deleteDoctorClosure,
} from "../db";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const ensureAdmin = (role: string) => {
  if (role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "تتطلب هذه العملية صلاحية مسؤول النظام." });
};
const ADMIN_ACCESS_CODE = "hb1519980";
const patientProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "user") throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية متاحة لمسار المريض فقط." });
  return next();
});
const doctorProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "doctor") throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية متاحة لمسار الطبيب فقط." });
  return next();
});

export const clinicRouter = router({
  catalog: router({
    specialties: publicProcedure.query(() => listSpecialties()),
    hospitals: publicProcedure.query(() => listHospitals()),
    doctors: publicProcedure.input(z.object({ specialtyId: z.number().int().positive().optional() })).query(({ input }) => listDoctors(input.specialtyId)),
  }),
  patient: router({
    profile: patientProcedure.query(({ ctx }) => getPatientProfile(ctx.user.id)),
    favorites: patientProcedure.query(({ ctx }) => listFavoriteDoctors(ctx.user.id)),
    toggleFavorite: patientProcedure.input(z.object({ doctorId: z.number().int().positive() })).mutation(({ ctx, input }) => toggleFavoriteDoctor(ctx.user.id, input.doctorId)),
    saveProfile: patientProcedure.input(z.object({
      fullName: z.string().trim().min(3).max(160),
      phone: z.string().trim().min(7).max(40),
      birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      gender: z.enum(["male", "female", "unspecified"]),
    })).mutation(({ ctx, input }) => savePatientProfile(ctx.user.id, input)),
    appointments: patientProcedure.query(({ ctx }) => listPatientAppointments(ctx.user.id)),
    monthAvailability: patientProcedure.input(z.object({ doctorId: z.number().int().positive(), month: z.string().regex(/^\d{4}-\d{2}$/) })).query(({ ctx, input }) => listDoctorMonthAvailability(ctx.user.id, input.doctorId, input.month)),
    slotAvailability: patientProcedure.input(z.object({ doctorId: z.number().int().positive(), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) })).query(({ ctx, input }) => listPatientSlotAvailability(ctx.user.id, input.doctorId, input.date)),
    book: patientProcedure.input(z.object({
      doctorId: z.number().int().positive(),
      appointmentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      appointmentTime: z.string().regex(/^\d{2}:\d{2}$/),
      patientNote: z.string().trim().max(1200).optional(),
    })).mutation(({ ctx, input }) => createAppointment(ctx.user.id, input)),
    cancel: patientProcedure.input(z.object({ appointmentId: z.number().int().positive() })).mutation(({ ctx, input }) => cancelPatientAppointment(ctx.user.id, input.appointmentId)),
    deleteOldAppointments: patientProcedure.mutation(({ ctx }) => deleteOldPatientAppointments(ctx.user.id)),
    deleteAppointment: patientProcedure.input(z.object({ appointmentId: z.number().int().positive() })).mutation(({ ctx, input }) => deletePatientAppointment(ctx.user.id, input.appointmentId)),
    records: patientProcedure.query(({ ctx }) => listPatientRecords(ctx.user.id)),
    files: patientProcedure.query(({ ctx }) => listPatientFiles(ctx.user.id)),
    uploadFile: patientProcedure.input(z.object({
      originalName: z.string().trim().min(1).max(255),
      mimeType: z.string().trim().min(1).max(100),
      dataUrl: z.string().min(20).max(7_000_000),
    })).mutation(({ ctx, input }) => uploadPatientFile(ctx.user.id, input)),
    uploadAppointmentFile: patientProcedure.input(z.object({
      appointmentId: z.number().int().positive(),
      originalName: z.string().trim().min(1).max(255),
      mimeType: z.string().trim().min(1).max(100),
      dataUrl: z.string().min(20).max(7_000_000),
    })).mutation(({ ctx, input }) => uploadPatientFile(ctx.user.id, input)),
  }),
  doctor: router({
    me: protectedProcedure.query(({ ctx }) => getDoctorForUser(ctx.user.id)),
    claim: protectedProcedure.input(z.object({ doctorId: z.number().int().positive(), accessCode: z.string().min(8).max(128) })).mutation(({ ctx, input }) => claimDoctorProfile(ctx.user.id, input.doctorId, input.accessCode)),
    appointments: doctorProcedure.query(({ ctx }) => listDoctorAppointments(ctx.user.id)),
    files: doctorProcedure.query(({ ctx }) => listDoctorAppointmentFiles(ctx.user.id)),
    closures: doctorProcedure.query(({ ctx }) => listDoctorClosures(ctx.user.id)),
    createClosure: doctorProcedure.input(z.object({ dates: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).min(1).max(180), startTime: z.string().regex(/^\d{2}:\d{2}$/).optional(), endTime: z.string().regex(/^\d{2}:\d{2}$/).optional(), note: z.string().trim().max(500).optional() })).mutation(({ ctx, input }) => createDoctorClosure(ctx.user.id, input)),
    deleteClosure: doctorProcedure.input(z.object({ closureId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteDoctorClosure(ctx.user.id, input.closureId)),
    closeDate: doctorProcedure.input(z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), note: z.string().trim().max(500).optional() })).mutation(({ ctx, input }) => closeDoctorDate(ctx.user.id, input.date, input.note)),
    updateAppointment: doctorProcedure.input(z.object({
      appointmentId: z.number().int().positive(),
      status: z.enum(["confirmed", "declined", "cancelled", "rescheduled"]),
      doctorNote: z.string().trim().max(1200).optional(),
      proposedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      proposedTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
    })).mutation(({ ctx, input }) => updateDoctorAppointment(ctx.user.id, input)),
    updateSchedule: doctorProcedure.input(z.object({ scheduleStart: z.string().regex(/^\d{2}:\d{2}$/), scheduleEnd: z.string().regex(/^\d{2}:\d{2}$/), availabilityDays: z.string().regex(/^[0-6](,[0-6])*$/), blockedDates: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(120) })).mutation(({ ctx, input }) => updateDoctorSchedule(ctx.user.id, input)),
    createRecord: doctorProcedure.input(z.object({
      appointmentId: z.number().int().positive(),
      diagnosis: z.string().trim().max(2000).optional(),
      medications: z.string().trim().max(2000).optional(),
      tests: z.string().trim().max(2000).optional(),
      notes: z.string().trim().max(2000).optional(),
    })).mutation(({ ctx, input }) => createMedicalRecord(ctx.user.id, input)),
  }),
  notifications: router({
    list: protectedProcedure.query(({ ctx }) => listNotifications(ctx.user.id)),
    markRead: protectedProcedure.input(z.object({ notificationId: z.number().int().positive() })).mutation(({ ctx, input }) => markNotificationRead(ctx.user.id, input.notificationId)),
  }),
  admin: router({
    verifyAccess: protectedProcedure.input(z.object({ accessCode: z.string().min(1).max(128) })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); if (input.accessCode !== ADMIN_ACCESS_CODE) throw new TRPCError({ code: "UNAUTHORIZED", message: "رمز مسؤول النظام غير صحيح." }); return { success: true }; }),
    summary: protectedProcedure.query(({ ctx }) => { ensureAdmin(ctx.user.role); return getAdminSummary(); }),
    addDoctor: protectedProcedure.input(z.object({
      fullName: z.string().trim().min(3).max(160),
      phone: z.string().trim().min(7).max(40),
      specialtyId: z.number().int().positive(),
      customSpecialty: z.string().trim().max(160).optional(),
      hospitalId: z.number().int().positive().optional(),
      clinicName: z.string().trim().max(180).optional(),
      clinicAddress: z.string().trim().max(300).optional(),
      clinicLocationUrl: z.string().url().max(700).optional(),
      photoUrl: z.string().url().max(700).optional(),
      bio: z.string().trim().max(1200).optional(),
      accessCode: z.string().min(8).max(128),
      scheduleStart: z.string().regex(/^\d{2}:\d{2}$/),
      scheduleEnd: z.string().regex(/^\d{2}:\d{2}$/),
      slotMinutes: z.number().int().min(10).max(120),
      availabilityDays: z.string().regex(/^[0-6](,[0-6])*$/),
      blockedDates: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(120).optional(),
    })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); return addDoctor(input); }),
    updateDoctor: protectedProcedure.input(z.object({
      id: z.number().int().positive(), fullName: z.string().trim().min(3).max(160), phone: z.string().trim().min(7).max(40), specialtyId: z.number().int().positive(), customSpecialty: z.string().trim().max(160).optional(), hospitalId: z.number().int().positive().optional(), clinicName: z.string().trim().max(180).optional(), clinicAddress: z.string().trim().max(300).optional(), clinicLocationUrl: z.string().url().max(700).optional(), photoUrl: z.string().url().max(700).optional(), bio: z.string().trim().max(1200).optional(), scheduleStart: z.string().regex(/^\d{2}:\d{2}$/), scheduleEnd: z.string().regex(/^\d{2}:\d{2}$/), slotMinutes: z.number().int().min(10).max(120), availabilityDays: z.string().regex(/^[0-6](,[0-6])*$/), blockedDates: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(120).optional(),
    })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); return updateDoctor(input); }),
    uploadDoctorPhoto: protectedProcedure.input(z.object({ doctorId: z.number().int().positive(), originalName: z.string().trim().max(180), mimeType: z.string().regex(/^image\//), dataUrl: z.string().max(5_000_000) })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); return uploadDoctorPhoto(input); }),
    deleteDoctor: protectedProcedure.input(z.object({ doctorId: z.number().int().positive() })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); return deleteDoctor(input.doctorId); }),
    changeDoctorAccessCode: protectedProcedure.input(z.object({ doctorId: z.number().int().positive(), accessCode: z.string().min(8).max(128) })).mutation(({ ctx, input }) => { ensureAdmin(ctx.user.role); return changeDoctorAccessCode(input.doctorId, input.accessCode); }),
  }),
});
