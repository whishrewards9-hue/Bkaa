import { describe, expect, it } from "vitest";
import type { Express, Request, Response } from "express";
import { applySecurity } from "./_core/security";

describe("server security middleware", () => {
  it("adds browser hardening headers and disables the Express signature", () => {
    const middlewares: Array<(...args: any[]) => void> = [];
    const app = {
      disable: (name: string) => expect(name).toBe("x-powered-by"),
      use: (...args: any[]) => middlewares.push(args[args.length - 1]),
    } as unknown as Express;
    applySecurity(app);
    const headers: Record<string, string> = {};
    const response = { setHeader: (name: string, value: string) => { headers[name] = value; } } as unknown as Response;
    middlewares[1]({ headers: {} } as Request, response, () => undefined);
    expect(headers["X-Content-Type-Options"]).toBe("nosniff");
    expect(headers["X-Frame-Options"]).toBe("DENY");
    expect(headers["Referrer-Policy"]).toBe("strict-origin-when-cross-origin");
    expect(headers["Permissions-Policy"]).toContain("camera=()");
  });

  it("allows the native Capacitor origin to call the API with credentials", () => {
    const middlewares: Array<(...args: any[]) => void> = [];
    const app = { disable: () => undefined, use: (...args: any[]) => middlewares.push(args[args.length - 1]) } as unknown as Express;
    applySecurity(app);
    const headers: Record<string, string> = {};
    let continued = false;
    const response = { setHeader: (name: string, value: string) => { headers[name] = value; }, status: () => response, json: () => response, sendStatus: () => response } as unknown as Response;
    middlewares[0]({ headers: { origin: "capacitor://localhost" }, method: "GET" } as unknown as Request, response, () => { continued = true; });
    expect(continued).toBe(true);
    expect(headers["Access-Control-Allow-Origin"]).toBe("capacitor://localhost");
    expect(headers["Access-Control-Allow-Credentials"]).toBe("true");
  });
});
