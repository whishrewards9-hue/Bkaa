import { and, asc, desc, eq, inArray, like, lt, ne, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql, { type Pool } from "mysql2";
import { randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import {
  appointments,
  doctors,
  favoriteDoctors,
  clinicClosures,
  hospitals,
  medicalRecords,
  notifications,
  patientFiles,
  patientProfiles,
  specialties,
  type InsertUser,
  users,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;
let _pool: Pool | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const connectionLimit = Math.min(40, Math.max(2, Number(process.env.DB_POOL_SIZE || 10)));
      _pool = mysql.createPool(process.env.DATABASE_URL);
      _pool.config.connectionLimit = connectionLimit;
      _pool.config.waitForConnections = true;
      _pool.config.queueLimit = 0;
      _pool.config.enableKeepAlive = true;
      _pool.config.keepAliveInitialDelay = 0;
      _db = drizzle(_pool);
      console.info(`[Database] Connection pool ready (${connectionLimit} connections).`);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
      _pool = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

const normalizePhone = (phone: string) => phone.trim().replace(/[\s()-]/g, "");
const MAX_HISTORY_ROWS = 1000;
const hashPassword = (phone: string, password: string) => scryptSync(password, `sehaty-user-v1:${normalizePhone(phone)}`, 64).toString("hex");
const verifyPassword = (phone: string, password: string, stored: string | null) => {
  if (!stored) return false;
  const actual = Buffer.from(hashPassword(phone, password), "hex");
  const expected = Buffer.from(stored, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
};

export async function createLocalPatientAccount(input: { fullName: string; phone: string; password: string; birthDate?: string; gender: "male" | "female" | "unspecified" }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const phone = normalizePhone(input.phone);
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone)).limit(1);
  if (existing.length) throw new Error("رقم الهاتف مستخدم مسبقاً. استخدم تسجيل الدخول بدلاً من إنشاء حساب جديد.");
  const result = await db.insert(users).values({ openId: `local_patient_${randomUUID()}`, name: input.fullName.trim(), phone, passwordHash: hashPassword(phone, input.password), loginMethod: "phone", role: "user" });
  const userId = Number(result[0].insertId);
  await db.insert(patientProfiles).values({ userId, fullName: input.fullName.trim(), phone, birthDate: input.birthDate || null, gender: input.gender });
  return getUserById(userId);
}

export async function authenticateLocalPatient(phoneInput: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const phone = normalizePhone(phoneInput);
  const rows = await db.select().from(users).where(and(eq(users.phone, phone), eq(users.role, "user"))).limit(1);
  const user = rows[0];
  if (!user || !verifyPassword(phone, password, user.passwordHash)) throw new Error("رقم الهاتف أو كلمة المرور غير صحيحين.");
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
  return user;
}

export async function authenticateLocalDoctor(doctorId: number, accessCode: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(doctors).where(and(eq(doctors.id, doctorId), eq(doctors.active, true))).limit(1);
  const doctor = rows[0];
  if (!doctor || !doctor.accessCodeHash || hashAccessCode(accessCode) !== doctor.accessCodeHash) throw new Error("اسم الطبيب أو كلمة المرور غير صحيحين.");
  let user = doctor.userId ? await getUserById(doctor.userId) : undefined;
  if (!user) {
    const result = await db.insert(users).values({ openId: `local_doctor_${doctor.id}`, name: doctor.fullName, phone: null, passwordHash: null, loginMethod: "doctor_code", role: "doctor" });
    await db.update(doctors).set({ userId: Number(result[0].insertId) }).where(eq(doctors.id, doctor.id));
    user = await getUserById(Number(result[0].insertId));
  }
  if (!user) throw new Error("تعذر إنشاء جلسة الطبيب.");
  await db.update(users).set({ lastSignedIn: new Date(), role: "doctor" }).where(eq(users.id, user.id));
  return user;
}

export async function authenticateLocalAdmin(accessCode: string) {
  if (accessCode !== "hb1519980") throw new Error("كلمة مرور المسؤول غير صحيحة.");
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  let user = await getUserByOpenId("local_admin");
  if (!user) {
    const result = await db.insert(users).values({ openId: "local_admin", name: "مسؤول النظام", phone: null, passwordHash: null, loginMethod: "admin_code", role: "admin" });
    user = await getUserById(Number(result[0].insertId));
  }
  if (!user) throw new Error("تعذر إنشاء جلسة المسؤول.");
  await db.update(users).set({ lastSignedIn: new Date(), role: "admin" }).where(eq(users.id, user.id));
  return user;
}

const hashAccessCode = (code: string) => scryptSync(code, "sehaty-bekaa-v1", 64).toString("hex");
const activeAppointmentStatuses = ["pending", "confirmed", "rescheduled"] as const;

const seededHospitals = [
  { name: "المستشفى اللبناني الفرنسي", area: "زحلة", phone: "08-810121 / 2 / 3", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى تل شيحا", area: "زحلة", phone: "08-807782 / 3 / 4", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى الخوري العام", area: "زحلة", phone: "08-807000 / 1 / 2 / 3", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى البقاع", area: "تعلبايا", phone: "08-543150 / 151 / 152 / 153", website: "https://bekaahospital.com", sourceUrl: "https://bekaahospital.com/contact/" },
 { name: "مستشفى دار الأمل الجامعي", area: "دورس - بعلبك", phone: "08-340620", website: "https://www.dar-alamal.com", sourceUrl: "https://www.dar-alamal.com/about_page.php?lng=ENG&current=about" },
 { name: "مركز سلوم الطبي", area: "تعنايل", phone: "08-545100", website: "https://smc.com.lb/ar/", sourceUrl: "https://smc.com.lb/ar/" },
 { name: "مستشفى شتورة", area: "شتورة", phone: "08-544022 / 3 / 4", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "مستشفى رياق", area: "رياق - البقاع", phone: "08-901300 / 1 / 2 / 3 / 4 / 5", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "مستشفى تطري", area: "البقاع", phone: "08-370799 / 08-371903 / 03-833846", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "مستشفى د. حامد فرحات", area: "البقاع", phone: "08-660233", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى بحمد", area: "البقاع", phone: "08-591108", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى الخطيب", area: "زحلة", phone: "08-930570 / 1 / 3", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى دار الحكمة", area: "البقاع", phone: "08-379136 / 7 / 803-725323", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى الأطباء", area: "البقاع", phone: "08-563101", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى العاصي", area: "البقاع", phone: "08-200795 / 08-200238", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى فرحات الطبي", area: "البقاع", phone: "08-911570", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى ابن سينا", area: "البقاع", phone: "08-377811", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "مستشفى المرتضى", area: "البقاع", phone: "08-377880", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "مستشفى الريان", area: "البقاع", phone: "08-373682 / 08-372182", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
 { name: "المستشفى الجامعي", area: "البقاع", phone: "08-210560 / 08-210570", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "مستشفى البتول", area: "البقاع", phone: "08-200118", website: null, sourceUrl: "https://www.syndicateofhospitals.org.lb/Hospitals/Index/8" },
  { name: "المركز الطبي في الجامعة الأميركية في بيروت", area: "بيروت - الحمرا", phone: "01-350000 / 01-340460", website: "https://www.aubmc.org.lb", sourceUrl: "https://www.moph.gov.lb/en/HealthFacilities/view/3/188/84535/american-university-of-beirut-medical-center?facility_type=8" },
  { name: "مستشفى المقاصد", area: "بيروت", phone: "01-636000", website: null, sourceUrl: "https://moph.gov.lb/en/HealthFacilities/index/3/188/8/health-facility-locator" },
  { name: "مستشفى بيروت الحكومي", area: "بيروت", phone: "01-850213", website: null, sourceUrl: "https://moph.gov.lb/en/HealthFacilities/index/3/188/8/health-facility-locator" },
  { name: "مستشفى رزق", area: "الأشرفية - بيروت", phone: "01-200800", website: null, sourceUrl: "https://um.dk/libanon/en/travel-and-residence/usefulcontacts/" },
];
const seededSpecialties = [
 { name: "العلاج الفيزيائي", icon: "Activity", description: "تأهيل الحركة والآلام العضلية والمفصلية." },
 { name: "أمراض القلب", icon: "HeartPulse", description: "متابعة القلب والضغط واضطرابات النظم." },
  { name: "الطب الباطني", icon: "Stethoscope", description: "تشخيص ومتابعة الحالات الباطنية العامة." },
  { name: "طب الأطفال", icon: "Baby", description: "رعاية الأطفال ومتابعة نموهم وصحتهم." },
  { name: "طب الأسرة", icon: "Stethoscope", description: "رعاية أولية شاملة لجميع أفراد الأسرة." },
  { name: "الجلدية والتجميل", icon: "Stethoscope", description: "أمراض الجلد والشعر والأظافر والإجراءات الجلدية." },
  { name: "النسائية والتوليد", icon: "Stethoscope", description: "صحة المرأة والحمل والولادة." },
  { name: "العيون", icon: "Stethoscope", description: "فحص وعلاج أمراض العين والنظر." },
  { name: "الأنف والأذن والحنجرة", icon: "Stethoscope", description: "أمراض الأنف والأذن والحنجرة والجيوب." },
  { name: "الجراحة العامة", icon: "Stethoscope", description: "التقييم والعلاج الجراحي العام." },
  { name: "جراحة العظام", icon: "Stethoscope", description: "العظام والمفاصل والكسور والإصابات." },
  { name: "الأعصاب", icon: "Stethoscope", description: "الجهاز العصبي والصداع واضطرابات الحركة." },
  { name: "جراحة الأعصاب", icon: "Stethoscope", description: "الجراحات المتعلقة بالدماغ والعمود الفقري والأعصاب." },
  { name: "الكلى", icon: "Stethoscope", description: "أمراض الكلى ووظائفها والغسيل الكلوي." },
  { name: "المسالك البولية", icon: "Stethoscope", description: "الجهاز البولي وصحة الرجال والمسالك." },
  { name: "الجهاز الهضمي والكبد", icon: "Stethoscope", description: "المعدة والأمعاء والكبد والمرارة والبنكرياس." },
  { name: "أمراض الصدر والتنفس", icon: "Stethoscope", description: "الرئة والربو والحساسية واضطرابات التنفس." },
  { name: "الغدد والسكري", icon: "Stethoscope", description: "الغدد والهرمونات والسكري واضطرابات الاستقلاب." },
  { name: "الروماتيزم والمناعة", icon: "Stethoscope", description: "أمراض المفاصل والمناعة الذاتية." },
  { name: "أمراض الدم", icon: "Stethoscope", description: "اضطرابات الدم والتخثر وفقر الدم." },
  { name: "الأورام", icon: "Stethoscope", description: "تقييم ومتابعة حالات الأورام والعلاج الداعم." },
  { name: "الطب النفسي", icon: "Stethoscope", description: "الصحة النفسية واضطرابات المزاج والقلق." },
  { name: "طب الأسنان", icon: "Stethoscope", description: "صحة الفم والأسنان واللثة." },
  { name: "تقويم الأسنان", icon: "Stethoscope", description: "تصحيح ترتيب الأسنان والفكين." },
  { name: "طب الطوارئ", icon: "Stethoscope", description: "التقييم الطبي العاجل والإسعاف الأولي." },
  { name: "التخدير والعناية المركزة", icon: "Stethoscope", description: "التخدير والرعاية الحرجة ومراقبة الحالات." },
  { name: "الأشعة والتصوير الطبي", icon: "Stethoscope", description: "قراءة الصور والفحوصات الشعاعية." },
  { name: "الطب المخبري", icon: "Stethoscope", description: "التحاليل الطبية وعلم الأمراض المخبري." },
  { name: "التغذية العلاجية", icon: "Stethoscope", description: "خطط التغذية المرتبطة بالحالة الصحية." },
  { name: "علاج النطق واللغة", icon: "Stethoscope", description: "اضطرابات النطق واللغة والبلع." },
  { name: "السمع والتوازن", icon: "Stethoscope", description: "فحوصات السمع واضطرابات التوازن." },
  { name: "الطب الرياضي", icon: "Stethoscope", description: "إصابات الرياضة والعودة الآمنة للنشاط." },
  { name: "طب الشيخوخة", icon: "Stethoscope", description: "الرعاية الصحية لكبار السن والأمراض المزمنة." },
  { name: "الأمراض المعدية", icon: "Stethoscope", description: "الوقاية والتقييم والمتابعة للأمراض المعدية." },
  { name: "جراحة الأوعية الدموية", icon: "Stethoscope", description: "أمراض الشرايين والأوردة والدورة الدموية." },
];

export async function ensureSeedData() {
  const db = await getDb();
  if (!db) return;
  for (const hospital of seededHospitals) {
    await db.insert(hospitals).values(hospital).onDuplicateKeyUpdate({ set: { phone: hospital.phone, area: hospital.area, website: hospital.website, sourceUrl: hospital.sourceUrl } });
  }
  for (const specialty of seededSpecialties) {
    await db.insert(specialties).values(specialty).onDuplicateKeyUpdate({ set: { icon: specialty.icon, description: specialty.description, active: true } });
  }
  const existingDoctors = await db.select({ id: doctors.id }).from(doctors).limit(1);
  if (existingDoctors.length > 0) return;
  const seededSpecs = await db.select().from(specialties);
  const seededHosp = await db.select().from(hospitals);
  const specialtyId = (name: string) => seededSpecs.find(item => item.name === name)?.id;
  const hospitalId = (name: string) => seededHosp.find(item => item.name === name)?.id;
  const physio = specialtyId("العلاج الفيزيائي");
  const cardio = specialtyId("أمراض القلب");
  if (!physio || !cardio) return;
  await db.insert(doctors).values([
    { fullName: "د. نورا ناجي", phone: "71 000342", specialtyId: physio, hospitalId: hospitalId("مركز سلوم الطبي"), bio: "معالجة فيزيائية؛ متابعة خطط التأهيل والحركة.", accessCodeHash: hashAccessCode("admin123456$"), scheduleStart: "09:00", scheduleEnd: "16:00", slotMinutes: 10, availabilityDays: "1,2,3,4,5" },
    { fullName: "د. مالك خطيب", phone: "03 660833", specialtyId: cardio, hospitalId: hospitalId("المستشفى اللبناني الفرنسي"), bio: "اختصاص أمراض القلب وكهرباء القلب.", accessCodeHash: hashAccessCode("admin1234567$"), scheduleStart: "10:00", scheduleEnd: "17:00", slotMinutes: 10, availabilityDays: "1,2,3,4,5" },
  ]);
}

export async function listSpecialties() {
  await ensureSeedData();
  const db = await getDb();
  return db ? db.select().from(specialties).where(eq(specialties.active, true)).orderBy(asc(specialties.name)) : [];
}

export async function listHospitals() {
  await ensureSeedData();
  const db = await getDb();
  return db ? db.select().from(hospitals).orderBy(asc(hospitals.area), asc(hospitals.name)) : [];
}

export async function listDoctors(specialtyId?: number) {
  await ensureSeedData();
  const db = await getDb();
  if (!db) return [];
  const query = db.select({
    id: doctors.id, userId: doctors.userId, fullName: doctors.fullName, phone: doctors.phone, bio: doctors.bio, photoUrl: doctors.photoUrl,
    scheduleStart: doctors.scheduleStart, scheduleEnd: doctors.scheduleEnd, slotMinutes: doctors.slotMinutes,
    availabilityDays: doctors.availabilityDays, blockedDates: doctors.blockedDates, active: doctors.active,
    specialtyId: specialties.id, specialtyName: sql<string>`COALESCE(${doctors.customSpecialty}, ${specialties.name})`, specialtyDefaultName: specialties.name, specialtyIcon: specialties.icon,
    customSpecialty: doctors.customSpecialty, hospitalId: hospitals.id, hospitalName: doctors.clinicName, hospitalDefaultName: hospitals.name, hospitalArea: sql<string | null>`COALESCE(${doctors.clinicAddress}, ${hospitals.area})`,
    clinicName: doctors.clinicName, clinicAddress: doctors.clinicAddress, clinicLocationUrl: doctors.clinicLocationUrl,
  }).from(doctors).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).leftJoin(hospitals, eq(doctors.hospitalId, hospitals.id)).where(and(eq(doctors.active, true), specialtyId ? eq(doctors.specialtyId, specialtyId) : undefined));
  return query.orderBy(asc(doctors.fullName));
}

export async function getPatientProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(patientProfiles).where(eq(patientProfiles.userId, userId)).limit(1);
  return rows[0];
}

export async function savePatientProfile(userId: number, input: { fullName: string; phone: string; birthDate?: string; gender: "male" | "female" | "unspecified" }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.insert(patientProfiles).values({ userId, ...input, birthDate: input.birthDate || null }).onDuplicateKeyUpdate({ set: { fullName: input.fullName, phone: input.phone, birthDate: input.birthDate || null, gender: input.gender } });
  return getPatientProfile(userId);
}

export async function listFavoriteDoctors(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ doctorId: favoriteDoctors.doctorId, createdAt: favoriteDoctors.createdAt, fullName: doctors.fullName, phone: doctors.phone, specialtyId: specialties.id, specialtyName: sql<string>`COALESCE(${doctors.customSpecialty}, ${specialties.name})`, hospitalName: doctors.clinicName, hospitalDefaultName: hospitals.name, clinicAddress: doctors.clinicAddress, clinicLocationUrl: doctors.clinicLocationUrl, photoUrl: doctors.photoUrl, scheduleStart: doctors.scheduleStart, scheduleEnd: doctors.scheduleEnd, active: doctors.active })
    .from(favoriteDoctors).innerJoin(doctors, eq(favoriteDoctors.doctorId, doctors.id)).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).leftJoin(hospitals, eq(doctors.hospitalId, hospitals.id)).where(eq(favoriteDoctors.userId, userId)).orderBy(desc(favoriteDoctors.createdAt));
}

export async function toggleFavoriteDoctor(userId: number, doctorId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorRaw(doctorId);
  if (!doctor || !doctor.active) throw new Error("الطبيب غير متاح حالياً.");
  const existing = await db.select({ id: favoriteDoctors.id }).from(favoriteDoctors).where(and(eq(favoriteDoctors.userId, userId), eq(favoriteDoctors.doctorId, doctorId))).limit(1);
  if (existing[0]) {
    await db.delete(favoriteDoctors).where(eq(favoriteDoctors.id, existing[0].id));
    return { favorite: false, doctorId };
  }
  await db.insert(favoriteDoctors).values({ userId, doctorId });
  return { favorite: true, doctorId };
}

export async function getDoctorForUser(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ id: doctors.id, fullName: doctors.fullName, specialtyName: sql<string>`COALESCE(${doctors.customSpecialty}, ${specialties.name})`, specialtyId: specialties.id, scheduleStart: doctors.scheduleStart, scheduleEnd: doctors.scheduleEnd, slotMinutes: doctors.slotMinutes, availabilityDays: doctors.availabilityDays, blockedDates: doctors.blockedDates, hospitalName: doctors.clinicName, hospitalDefaultName: hospitals.name, clinicName: doctors.clinicName, clinicAddress: doctors.clinicAddress, clinicLocationUrl: doctors.clinicLocationUrl, photoUrl: doctors.photoUrl })
    .from(doctors).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).leftJoin(hospitals, eq(doctors.hospitalId, hospitals.id)).where(eq(doctors.userId, userId)).limit(1);
  return rows[0];
}

export async function claimDoctorProfile(userId: number, doctorId: number, accessCode: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(doctors).where(eq(doctors.id, doctorId)).limit(1);
  const doctor = rows[0];
  if (!doctor || !doctor.active || !doctor.accessCodeHash) throw new Error("بيانات الطبيب غير صالحة.");
  const received = Buffer.from(hashAccessCode(accessCode), "hex");
  const expected = Buffer.from(doctor.accessCodeHash, "hex");
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) throw new Error("رمز وصول الطبيب غير صحيح.");
  if (doctor.userId && doctor.userId !== userId) throw new Error("هذا الحساب الطبي مرتبط بمستخدم آخر.");
  await db.update(doctors).set({ userId }).where(eq(doctors.id, doctorId));
  await db.update(users).set({ role: "doctor" }).where(eq(users.id, userId));
  return getDoctorForUser(userId);
}

const parseBlockedDates = (value: string | null) => {
  try { return value ? JSON.parse(value) as string[] : []; } catch { return []; }
};

const isAvailableAt = (doctor: { scheduleStart: string; scheduleEnd: string; availabilityDays: string; blockedDates: string | null }, date: string, time: string, closures: Array<{ closureDate: string; startTime: string | null; endTime: string | null }> = []) => {
  const day = new Date(`${date}T12:00:00`).getDay();
  const days = doctor.availabilityDays.split(",").map(Number);
  const blocked = parseBlockedDates(doctor.blockedDates);
  const closed = closures.some(item => item.closureDate === date && (!item.startTime || !item.endTime || (time >= item.startTime && time < item.endTime)));
  return days.includes(day) && !blocked.includes(date) && !closed && time >= doctor.scheduleStart && time < doctor.scheduleEnd;
};

async function getDoctorRaw(doctorId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(doctors).where(eq(doctors.id, doctorId)).limit(1);
  return rows[0];
}

export async function createAppointment(userId: number, input: { doctorId: number; appointmentDate: string; appointmentTime: string; patientNote?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("يرجى إكمال الملف الصحي قبل إرسال الحجز.");
  const doctor = await getDoctorRaw(input.doctorId);
  if (!doctor || !doctor.active) throw new Error("الطبيب غير متاح للحجز.");
  const closures = await db.select({ closureDate: clinicClosures.closureDate, startTime: clinicClosures.startTime, endTime: clinicClosures.endTime }).from(clinicClosures).where(and(eq(clinicClosures.doctorId, doctor.id), eq(clinicClosures.closureDate, input.appointmentDate)));
  if (!isAvailableAt(doctor, input.appointmentDate, input.appointmentTime, closures)) throw new Error("الوقت المختار خارج دوام الطبيب أو داخل فترة إغلاق مؤقتة.");

  const doctorSlot = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.doctorId, doctor.id), eq(appointments.appointmentDate, input.appointmentDate), eq(appointments.appointmentTime, input.appointmentTime), inArray(appointments.status, activeAppointmentStatuses))).limit(1);
  if (doctorSlot.length) throw new Error("هذا الوقت محجوز أو بانتظار موافقة الطبيب؛ اختر موعداً آخر.");
  const patientSlot = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.patientId, patient.id), eq(appointments.appointmentDate, input.appointmentDate), eq(appointments.appointmentTime, input.appointmentTime), inArray(appointments.status, activeAppointmentStatuses))).limit(1);
  if (patientSlot.length) throw new Error("لديك موعد آخر في الوقت نفسه؛ اختر وقتاً مختلفاً.");

  const result = await db.insert(appointments).values({ patientId: patient.id, doctorId: doctor.id, appointmentDate: input.appointmentDate, appointmentTime: input.appointmentTime, patientNote: input.patientNote || null });
  if (doctor.userId) await createNotification(doctor.userId, "طلب حجز جديد", `طلب ${patient.fullName} موعداً في ${input.appointmentDate} الساعة ${input.appointmentTime}.`, "appointment_request");
  return { id: Number(result[0].insertId) };
}

export async function listPatientAppointments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const patient = await getPatientProfile(userId);
  if (!patient) return [];
  return db.select({ id: appointments.id, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime, status: appointments.status, patientNote: appointments.patientNote, doctorNote: appointments.doctorNote, proposedDate: appointments.proposedDate, proposedTime: appointments.proposedTime, createdAt: appointments.createdAt, doctorName: doctors.fullName, specialtyName: specialties.name, hospitalName: hospitals.name })
    .from(appointments).innerJoin(doctors, eq(appointments.doctorId, doctors.id)).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).leftJoin(hospitals, eq(doctors.hospitalId, hospitals.id)).where(eq(appointments.patientId, patient.id)).orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime)).limit(MAX_HISTORY_ROWS);
}

const timeSlotsForDoctor = (doctor: { scheduleStart: string; scheduleEnd: string; slotMinutes: number }) => {
  const result: string[] = [];
  const [startHour, startMinute] = doctor.scheduleStart.split(":").map(Number);
  const [endHour, endMinute] = doctor.scheduleEnd.split(":").map(Number);
  let current = startHour * 60 + startMinute;
  const limit = endHour * 60 + endMinute;
  while (current < limit) {
    result.push(`${String(Math.floor(current / 60)).padStart(2, "0")}:${String(current % 60).padStart(2, "0")}`);
    current += doctor.slotMinutes;
  }
  return result;
};

export async function listPatientSlotAvailability(userId: number, doctorId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("ملف المريض غير موجود.");
  const doctor = await getDoctorRaw(doctorId);
  if (!doctor || !doctor.active) throw new Error("الطبيب غير متاح للحجز.");
  const day = new Date(`${date}T12:00:00`).getDay();
  const blocked = parseBlockedDates(doctor.blockedDates);
  const working = doctor.availabilityDays.split(",").map(Number).includes(day) && !blocked.includes(date);
  const closures = await db.select({ closureDate: clinicClosures.closureDate, startTime: clinicClosures.startTime, endTime: clinicClosures.endTime }).from(clinicClosures).where(and(eq(clinicClosures.doctorId, doctorId), eq(clinicClosures.closureDate, date)));
  const booked = await db.select({ appointmentTime: appointments.appointmentTime }).from(appointments).where(and(eq(appointments.doctorId, doctorId), eq(appointments.appointmentDate, date), inArray(appointments.status, activeAppointmentStatuses)));
  const bookedTimes = new Set(booked.map(item => item.appointmentTime));
  return timeSlotsForDoctor(doctor).map(time => ({ time, status: !working || !isAvailableAt(doctor, date, time, closures) ? "unavailable" as const : bookedTimes.has(time) ? "booked" as const : "available" as const }));
}

export async function listDoctorMonthAvailability(userId: number, doctorId: number, month: string) {
  const db = await getDb();
  if (!db) return [];
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("ملف المريض غير موجود.");
  const doctor = await getDoctorRaw(doctorId);
  if (!doctor || !doctor.active) throw new Error("الطبيب غير متاح للحجز.");
  const blocked = new Set(parseBlockedDates(doctor.blockedDates));
  const totalSlots = timeSlotsForDoctor(doctor).length;
  const closures = await db.select({ closureDate: clinicClosures.closureDate, startTime: clinicClosures.startTime, endTime: clinicClosures.endTime }).from(clinicClosures).where(and(eq(clinicClosures.doctorId, doctorId), like(clinicClosures.closureDate, `${month}-%`)));
  const rows = await db.select({ appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime }).from(appointments).where(and(eq(appointments.doctorId, doctorId), like(appointments.appointmentDate, `${month}-%`), inArray(appointments.status, activeAppointmentStatuses)));
  const bookedByDate = new Map<string, Set<string>>();
  for (const row of rows) {
    const set = bookedByDate.get(row.appointmentDate) || new Set<string>();
    set.add(row.appointmentTime); bookedByDate.set(row.appointmentDate, set);
  }
  const [year, monthNumber] = month.split("-").map(Number);
  const count = new Date(year, monthNumber, 0).getDate();
  const today = new Date().toISOString().slice(0, 10);
  return Array.from({ length: count }, (_, index) => {
    const date = `${month}-${String(index + 1).padStart(2, "0")}`;
    const day = new Date(`${date}T12:00:00`).getDay();
    const weeklyWorking = date >= today && doctor.availabilityDays.split(",").map(Number).includes(day) && !blocked.has(date);
    const booked = bookedByDate.get(date)?.size || 0;
    const closedTimes = new Set(closures.filter(item => item.closureDate === date).flatMap(item => timeSlotsForDoctor(doctor).filter(time => !isAvailableAt(doctor, date, time, [item])))).size;
    const available = Math.max(0, totalSlots - booked - closedTimes);
    const working = weeklyWorking && closedTimes < totalSlots;
    return { date, status: !working ? "unavailable" as const : available === 0 ? "full" as const : booked > 0 || closedTimes > 0 ? "partial" as const : "available" as const, available, total: totalSlots };
  });
}

export async function deletePatientAppointment(userId: number, appointmentId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("ملف المريض غير موجود.");
  const rows = await db.select().from(appointments).where(and(eq(appointments.id, appointmentId), eq(appointments.patientId, patient.id))).limit(1);
  const appointment = rows[0];
  if (!appointment) throw new Error("الحجز غير موجود.");
  await db.delete(appointments).where(eq(appointments.id, appointmentId));
  const doctor = await getDoctorRaw(appointment.doctorId);
  if (doctor?.userId) await createNotification(doctor.userId, "حذف حجز", `حذف المريض ${patient.fullName} الحجز بتاريخ ${appointment.appointmentDate} الساعة ${appointment.appointmentTime}.`, "appointment_deleted");
  return { success: true };
}

export async function resetPatientPasswordByPhone(phoneInput: string, newPassword: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const phone = normalizePhone(phoneInput);
  const rows = await db.select().from(users).where(and(eq(users.phone, phone), eq(users.role, "user"))).limit(1);
  if (!rows[0]) throw new Error("لا يوجد حساب مريض مرتبط بهذا الرقم.");
  await db.update(users).set({ passwordHash: hashPassword(phone, newPassword) }).where(eq(users.id, rows[0].id));
  return { success: true };
}

export async function adminResetPatientPassword(phoneInput: string, newPassword: string) {
  return resetPatientPasswordByPhone(phoneInput, newPassword);
}

export async function deleteOldPatientAppointments(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("ملف المريض غير موجود.");
  const today = new Date().toISOString().slice(0, 10);
  await db.delete(appointments).where(and(eq(appointments.patientId, patient.id), lt(appointments.appointmentDate, today)));
  return { success: true };
}

export async function cancelPatientAppointment(userId: number, appointmentId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("ملف المريض غير موجود.");
  const rows = await db.select().from(appointments).where(and(eq(appointments.id, appointmentId), eq(appointments.patientId, patient.id))).limit(1);
  const appointment = rows[0];
  if (!appointment || appointment.status !== "pending") throw new Error("يمكن إلغاء الطلبات المعلّقة فقط.");
  await db.update(appointments).set({ status: "cancelled" }).where(eq(appointments.id, appointmentId));
  const doctor = await getDoctorRaw(appointment.doctorId);
  if (doctor?.userId) await createNotification(doctor.userId, "إلغاء طلب حجز", "ألغى المريض طلب الحجز المعلّق.", "appointment_cancelled");
  return { success: true };
}

export async function listDoctorAppointments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const doctor = await getDoctorForUser(userId);
  if (!doctor) return [];
  return db.select({ id: appointments.id, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime, status: appointments.status, patientNote: appointments.patientNote, doctorNote: appointments.doctorNote, proposedDate: appointments.proposedDate, proposedTime: appointments.proposedTime, createdAt: appointments.createdAt, patientName: patientProfiles.fullName, patientPhone: patientProfiles.phone, patientId: patientProfiles.id })
    .from(appointments).innerJoin(patientProfiles, eq(appointments.patientId, patientProfiles.id)).where(eq(appointments.doctorId, doctor.id)).orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime)).limit(MAX_HISTORY_ROWS);
}

export async function updateDoctorAppointment(userId: number, input: { appointmentId: number; status: "confirmed" | "declined" | "cancelled" | "rescheduled"; doctorNote?: string; proposedDate?: string; proposedTime?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  const rows = await db.select().from(appointments).where(and(eq(appointments.id, input.appointmentId), eq(appointments.doctorId, doctor.id))).limit(1);
  const appointment = rows[0];
  if (!appointment) throw new Error("الحجز غير موجود أو لا تملك صلاحية الوصول إليه.");
  if (input.status === "rescheduled" && (!input.proposedDate || !input.proposedTime)) throw new Error("حدّد التاريخ والوقت المقترحين للتعديل.");
  if (input.status === "rescheduled") {
    const clashes = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.doctorId, doctor.id), eq(appointments.appointmentDate, input.proposedDate!), eq(appointments.appointmentTime, input.proposedTime!), ne(appointments.id, appointment.id), inArray(appointments.status, activeAppointmentStatuses))).limit(1);
    if (clashes.length) throw new Error("الوقت المقترح محجوز، اختر وقتاً آخر.");
  }
  await db.update(appointments).set({ status: input.status, doctorNote: input.doctorNote || null, proposedDate: input.status === "rescheduled" ? input.proposedDate : null, proposedTime: input.status === "rescheduled" ? input.proposedTime : null }).where(eq(appointments.id, appointment.id));
  const patient = await db.select().from(patientProfiles).where(eq(patientProfiles.id, appointment.patientId)).limit(1);
  if (patient[0]) {
    const messages = { confirmed: "تم تأكيد موعدك الطبي.", declined: "تعذّر قبول طلب الحجز. يرجى اختيار وقت آخر.", cancelled: "تم إلغاء الموعد من قبل العيادة.", rescheduled: `اقترحت العيادة موعداً جديداً: ${input.proposedDate} الساعة ${input.proposedTime}.` };
    await createNotification(patient[0].userId, "تحديث على موعدك", messages[input.status], "appointment_update");
  }
  return { success: true };
}

export async function updateDoctorSchedule(userId: number, input: { scheduleStart: string; scheduleEnd: string; availabilityDays: string; blockedDates: string[] }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  await db.update(doctors).set({ scheduleStart: input.scheduleStart, scheduleEnd: input.scheduleEnd, availabilityDays: input.availabilityDays, blockedDates: JSON.stringify(input.blockedDates) }).where(eq(doctors.id, doctor.id));
  return { success: true };
}

export async function listDoctorClosures(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const doctor = await getDoctorForUser(userId);
  if (!doctor) return [];
  return db.select({ id: clinicClosures.id, closureDate: clinicClosures.closureDate, startTime: clinicClosures.startTime, endTime: clinicClosures.endTime, note: clinicClosures.note, createdAt: clinicClosures.createdAt }).from(clinicClosures).where(eq(clinicClosures.doctorId, doctor.id)).orderBy(asc(clinicClosures.closureDate), asc(clinicClosures.startTime)).limit(MAX_HISTORY_ROWS);
}

export async function createDoctorClosure(userId: number, input: { dates: string[]; startTime?: string; endTime?: string; note?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  const dates = Array.from(new Set(input.dates)).sort();
  if (!dates.length) throw new Error("اختر يوماً واحداً على الأقل للإغلاق.");
  const hasStart = Boolean(input.startTime), hasEnd = Boolean(input.endTime);
  if (hasStart !== hasEnd) throw new Error("اختر وقت البداية والنهاية معاً، أو اتركهما لإغلاق اليوم كاملاً.");
  if (hasStart && input.startTime! >= input.endTime!) throw new Error("وقت نهاية الإغلاق يجب أن يأتي بعد وقت البداية.");
  const startTime = hasStart ? input.startTime! : null;
  const endTime = hasEnd ? input.endTime! : null;
  let cancelled = 0;
  for (const date of dates) {
    await db.insert(clinicClosures).values({ doctorId: doctor.id, closureDate: date, startTime, endTime, note: input.note || "إغلاق مؤقت للعيادة." });
    const candidates = await db.select({ id: appointments.id, appointmentTime: appointments.appointmentTime, patientId: appointments.patientId }).from(appointments).where(and(eq(appointments.doctorId, doctor.id), eq(appointments.appointmentDate, date), inArray(appointments.status, activeAppointmentStatuses)));
    const affected = candidates.filter(item => !startTime || !endTime || (item.appointmentTime >= startTime && item.appointmentTime < endTime));
    if (affected.length) {
      await db.update(appointments).set({ status: "cancelled", doctorNote: input.note || "أُغلق هذا الوقت مؤقتاً من قبل العيادة." }).where(inArray(appointments.id, affected.map(item => item.id)));
      const patients = await db.select({ userId: patientProfiles.userId }).from(patientProfiles).where(inArray(patientProfiles.id, affected.map(item => item.patientId)));
      await Promise.all(patients.map(item => createNotification(item.userId, "إغلاق مؤقت للعيادة", `أُغلق موعدك بتاريخ ${date}${startTime ? ` من الساعة ${startTime} إلى ${endTime}` : " بسبب إغلاق العيادة"}.`, "clinic_closure")));
      cancelled += affected.length;
    }
  }
  return { success: true, dates, cancelled };
}

export async function deleteDoctorClosure(userId: number, closureId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  const result = await db.delete(clinicClosures).where(and(eq(clinicClosures.id, closureId), eq(clinicClosures.doctorId, doctor.id)));
  return { success: true, removed: Number(result[0]?.affectedRows || 0) > 0 };
}

export async function closeDoctorDate(userId: number, date: string, note = "أغلقت العيادة هذا اليوم بسبب ظرف طارئ.") {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  const blocked = new Set(parseBlockedDates(doctor.blockedDates));
  blocked.add(date);
  await db.update(doctors).set({ blockedDates: JSON.stringify(Array.from(blocked).sort()) }).where(eq(doctors.id, doctor.id));
  const affected = await db.select({ id: appointments.id, patientId: appointments.patientId }).from(appointments).where(and(eq(appointments.doctorId, doctor.id), eq(appointments.appointmentDate, date), inArray(appointments.status, activeAppointmentStatuses)));
  if (affected.length) {
    await db.update(appointments).set({ status: "cancelled", doctorNote: note }).where(and(eq(appointments.doctorId, doctor.id), eq(appointments.appointmentDate, date), inArray(appointments.status, activeAppointmentStatuses)));
    const patients = await db.select({ userId: patientProfiles.userId }).from(patientProfiles).where(inArray(patientProfiles.id, affected.map(item => item.patientId)));
    await Promise.all(patients.map(item => createNotification(item.userId, "إغلاق العيادة", `أُغلقت عيادة الطبيب بتاريخ ${date}. ${note}`, "clinic_closed")));
  }
  return { success: true, cancelled: affected.length };
}

export async function createMedicalRecord(userId: number, input: { appointmentId: number; diagnosis?: string; medications?: string; tests?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const doctor = await getDoctorForUser(userId);
  if (!doctor) throw new Error("هذا الحساب غير مرتبط بملف طبيب.");
  const rows = await db.select().from(appointments).where(and(eq(appointments.id, input.appointmentId), eq(appointments.doctorId, doctor.id))).limit(1);
  const appointment = rows[0];
  if (!appointment) throw new Error("لا يمكن إضافة سجل لهذا الحجز.");
  const result = await db.insert(medicalRecords).values({ patientId: appointment.patientId, doctorId: doctor.id, appointmentId: appointment.id, diagnosis: input.diagnosis || null, medications: input.medications || null, tests: input.tests || null, notes: input.notes || null });
  const patient = await db.select().from(patientProfiles).where(eq(patientProfiles.id, appointment.patientId)).limit(1);
  if (patient[0]) await createNotification(patient[0].userId, "تمت إضافة تعليمات طبية", "أضاف الطبيب وصفة أو فحوصات إلى ملفك الطبي.", "medical_record");
  return { id: Number(result[0].insertId) };
}

export async function listPatientRecords(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const patient = await getPatientProfile(userId);
  if (!patient) return [];
  return db.select({ id: medicalRecords.id, diagnosis: medicalRecords.diagnosis, medications: medicalRecords.medications, tests: medicalRecords.tests, notes: medicalRecords.notes, createdAt: medicalRecords.createdAt, doctorName: doctors.fullName, specialtyName: specialties.name })
    .from(medicalRecords).innerJoin(doctors, eq(medicalRecords.doctorId, doctors.id)).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).where(eq(medicalRecords.patientId, patient.id)).orderBy(desc(medicalRecords.createdAt)).limit(MAX_HISTORY_ROWS);
}

export async function createNotification(recipientUserId: number, title: string, body: string, kind: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({ recipientUserId, title, body, kind });
}

export async function listNotifications(userId: number) {
  const db = await getDb();
  return db ? db.select().from(notifications).where(eq(notifications.recipientUserId, userId)).orderBy(desc(notifications.createdAt)).limit(20) : [];
}

export async function markNotificationRead(userId: number, notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(notifications).set({ read: true }).where(and(eq(notifications.id, notificationId), eq(notifications.recipientUserId, userId)));
  return { success: true };
}

export async function addDoctor(input: { fullName: string; phone: string; specialtyId: number; customSpecialty?: string; hospitalId?: number; clinicName?: string; clinicAddress?: string; clinicLocationUrl?: string; photoUrl?: string; bio?: string; accessCode: string; scheduleStart: string; scheduleEnd: string; slotMinutes: number; availabilityDays: string; blockedDates?: string[] }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const result = await db.insert(doctors).values({ ...input, customSpecialty: input.customSpecialty || null, hospitalId: input.hospitalId || null, clinicName: input.clinicName || null, clinicAddress: input.clinicAddress || null, clinicLocationUrl: input.clinicLocationUrl || null, photoUrl: input.photoUrl || null, bio: input.bio || null, accessCodeHash: hashAccessCode(input.accessCode), blockedDates: JSON.stringify(input.blockedDates || []) });
  return { id: Number(result[0].insertId) };
}

export async function updateDoctor(input: { id: number; fullName: string; phone: string; specialtyId: number; customSpecialty?: string; hospitalId?: number; clinicName?: string; clinicAddress?: string; clinicLocationUrl?: string; photoUrl?: string; bio?: string; scheduleStart: string; scheduleEnd: string; slotMinutes: number; availabilityDays: string; blockedDates?: string[] }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(doctors).set({ fullName: input.fullName, phone: input.phone, specialtyId: input.specialtyId, customSpecialty: input.customSpecialty || null, hospitalId: input.hospitalId || null, clinicName: input.clinicName || null, clinicAddress: input.clinicAddress || null, clinicLocationUrl: input.clinicLocationUrl || null, photoUrl: input.photoUrl || null, bio: input.bio || null, scheduleStart: input.scheduleStart, scheduleEnd: input.scheduleEnd, slotMinutes: input.slotMinutes, availabilityDays: input.availabilityDays, blockedDates: JSON.stringify(input.blockedDates || []) }).where(eq(doctors.id, input.id));
  return { success: true };
}

export async function uploadDoctorPhoto(input: { doctorId: number; originalName: string; mimeType: string; dataUrl: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  if (!input.mimeType.startsWith("image/")) throw new Error("يرجى اختيار صورة فقط.");
  const encoded = input.dataUrl.split(",")[1];
  if (!encoded) throw new Error("صيغة الصورة غير صالحة.");
  const buffer = Buffer.from(encoded, "base64");
  if (!buffer.length || buffer.length > 3_000_000) throw new Error("الحد الأقصى لصورة الطبيب هو 3 ميغابايت.");
  const safeName = input.originalName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const { storagePut } = await import("./storage");
  const stored = await storagePut(`doctors/${input.doctorId}/${safeName}`, buffer, input.mimeType);
  await db.update(doctors).set({ photoUrl: stored.url }).where(eq(doctors.id, input.doctorId));
  return { url: stored.url };
}

export async function deleteDoctor(doctorId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const linked = await db.select({ id: appointments.id }).from(appointments).where(eq(appointments.doctorId, doctorId)).limit(1);
  if (linked.length) throw new Error("لا يمكن حذف طبيب لديه حجوزات محفوظة؛ عطّل ملفه بدلاً من ذلك.");
  await db.delete(doctors).where(eq(doctors.id, doctorId));
  return { success: true };
}

export async function changeDoctorAccessCode(doctorId: number, accessCode: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(doctors).set({ accessCodeHash: hashAccessCode(accessCode) }).where(eq(doctors.id, doctorId));
  return { success: true };
}

export async function getAdminSummary() {
  await ensureSeedData();
  const db = await getDb();
  if (!db) return { doctors: [], appointments: [], counts: { patients: 0, doctors: 0, appointments: 0 } };
  const [doctorRows, appointmentRows, patientCountRows, doctorCountRows, appointmentCountRows] = await Promise.all([
    db.select({ id: doctors.id, fullName: doctors.fullName, phone: doctors.phone, specialtyId: doctors.specialtyId, hospitalId: doctors.hospitalId, specialtyName: sql<string>`COALESCE(${doctors.customSpecialty}, ${specialties.name})`, specialtyDefaultName: specialties.name, customSpecialty: doctors.customSpecialty, hospitalName: doctors.clinicName, hospitalDefaultName: hospitals.name, clinicName: doctors.clinicName, clinicAddress: doctors.clinicAddress, clinicLocationUrl: doctors.clinicLocationUrl, photoUrl: doctors.photoUrl, bio: doctors.bio, active: doctors.active, scheduleStart: doctors.scheduleStart, scheduleEnd: doctors.scheduleEnd, slotMinutes: doctors.slotMinutes, availabilityDays: doctors.availabilityDays, blockedDates: doctors.blockedDates }).from(doctors).innerJoin(specialties, eq(doctors.specialtyId, specialties.id)).leftJoin(hospitals, eq(doctors.hospitalId, hospitals.id)).orderBy(asc(doctors.fullName)),
    db.select({ id: appointments.id, status: appointments.status, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime, patientName: patientProfiles.fullName, doctorName: doctors.fullName }).from(appointments).innerJoin(patientProfiles, eq(appointments.patientId, patientProfiles.id)).innerJoin(doctors, eq(appointments.doctorId, doctors.id)).orderBy(desc(appointments.createdAt)).limit(50),
    db.select({ count: sql<number>`count(*)` }).from(patientProfiles),
    db.select({ count: sql<number>`count(*)` }).from(doctors),
    db.select({ count: sql<number>`count(*)` }).from(appointments),
  ]);
  return { doctors: doctorRows, appointments: appointmentRows, counts: { patients: Number(patientCountRows[0]?.count || 0), doctors: Number(doctorCountRows[0]?.count || 0), appointments: Number(appointmentCountRows[0]?.count || 0) } };
}

export async function uploadPatientFile(userId: number, input: { originalName: string; mimeType: string; dataUrl: string; appointmentId?: number }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const patient = await getPatientProfile(userId);
  if (!patient) throw new Error("يرجى إكمال الملف الصحي قبل رفع الملفات.");
  if (input.appointmentId) {
    const appointment = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.id, input.appointmentId), eq(appointments.patientId, patient.id))).limit(1);
    if (!appointment.length) throw new Error("لا يمكنك إرفاق ملف بهذا الحجز.");
  }
  const encoded = input.dataUrl.split(",")[1];
  if (!encoded) throw new Error("صيغة الملف غير صالحة.");
  const buffer = Buffer.from(encoded, "base64");
  if (!buffer.length || buffer.length > 5_000_000) throw new Error("الحد الأقصى لحجم الملف هو 5 ميغابايت.");
  const safeName = input.originalName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const { storagePut } = await import("./storage");
  const stored = await storagePut(`patients/${patient.id}/${safeName}`, buffer, input.mimeType);
  const result = await db.insert(patientFiles).values({ patientId: patient.id, appointmentId: input.appointmentId || null, originalName: input.originalName, mimeType: input.mimeType, fileKey: stored.key, url: stored.url });
  return { id: Number(result[0].insertId), url: stored.url, originalName: input.originalName };
}

export async function listDoctorAppointmentFiles(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const doctor = await getDoctorForUser(userId);
  if (!doctor) return [];
  return db.select({ id: patientFiles.id, appointmentId: patientFiles.appointmentId, originalName: patientFiles.originalName, mimeType: patientFiles.mimeType, url: patientFiles.url, uploadedAt: patientFiles.uploadedAt, patientName: patientProfiles.fullName, patientPhone: patientProfiles.phone, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime })
    .from(patientFiles)
    .innerJoin(appointments, eq(patientFiles.appointmentId, appointments.id))
    .innerJoin(patientProfiles, eq(patientFiles.patientId, patientProfiles.id))
    .where(eq(appointments.doctorId, doctor.id))
    .orderBy(desc(patientFiles.uploadedAt)).limit(MAX_HISTORY_ROWS);
}

export async function listPatientFiles(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const patient = await getPatientProfile(userId);
  if (!patient) return [];
  return db.select().from(patientFiles).where(eq(patientFiles.patientId, patient.id)).orderBy(desc(patientFiles.uploadedAt)).limit(MAX_HISTORY_ROWS);
}
