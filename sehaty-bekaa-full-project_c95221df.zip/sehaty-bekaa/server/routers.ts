import { COOKIE_NAME } from "@shared/const";
import { ONE_YEAR_MS } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { adminResetPatientPassword, authenticateLocalAdmin, authenticateLocalDoctor, authenticateLocalPatient, createLocalPatientAccount } from "./db";
import { aiRouter } from "./routers/ai";
import { clinicRouter } from "./routers/clinic";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    local: router({
      registerPatient: publicProcedure.input(z.object({ fullName: z.string().trim().min(3).max(160), phone: z.string().trim().min(7).max(40), password: z.string().min(8).max(128), birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), gender: z.enum(["male", "female", "unspecified"]) })).mutation(async ({ ctx, input }) => {
        try {
          const user = await createLocalPatientAccount(input);
          if (!user) throw new Error("تعذر إنشاء الحساب.");
          await setLocalSession(ctx, user.openId, user.name || input.fullName);
          return user;
        } catch (error) {
          throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "تعذر إنشاء الحساب." });
        }
      }),
      loginPatient: publicProcedure.input(z.object({ phone: z.string().trim().min(7).max(40), password: z.string().min(1).max(128) })).mutation(async ({ ctx, input }) => {
        try { const user = await authenticateLocalPatient(input.phone, input.password); await setLocalSession(ctx, user.openId, user.name || "مريض"); return user; }
        catch (error) { throw new TRPCError({ code: "UNAUTHORIZED", message: error instanceof Error ? error.message : "تعذر تسجيل الدخول." }); }
      }),
      loginDoctor: publicProcedure.input(z.object({ doctorId: z.number().int().positive(), accessCode: z.string().min(1).max(128) })).mutation(async ({ ctx, input }) => {
        try { const user = await authenticateLocalDoctor(input.doctorId, input.accessCode); await setLocalSession(ctx, user.openId, user.name || "طبيب"); return user; }
        catch (error) { throw new TRPCError({ code: "UNAUTHORIZED", message: error instanceof Error ? error.message : "تعذر تسجيل الدخول." }); }
      }),
      loginAdmin: publicProcedure.input(z.object({ accessCode: z.string().min(1).max(128) })).mutation(async ({ ctx, input }) => {
        try { const user = await authenticateLocalAdmin(input.accessCode); await setLocalSession(ctx, user.openId, user.name || "مسؤول النظام"); return user; }
        catch (error) { throw new TRPCError({ code: "UNAUTHORIZED", message: error instanceof Error ? error.message : "تعذر تسجيل الدخول." }); }
      }),
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  clinic: clinicRouter,
  admin: router({
    resetPatientPassword: protectedProcedure.input(z.object({ phone: z.string().trim().min(7).max(40), newPassword: z.string().min(8).max(128) })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية لمسؤول النظام فقط." });
      return adminResetPatientPassword(input.phone, input.newPassword);
    }),
  }),
  ai: aiRouter,
});

async function setLocalSession(ctx: { req: Parameters<typeof getSessionCookieOptions>[0]; res: { cookie: (name: string, value: string, options: Record<string, unknown>) => void } }, openId: string, name: string) {
  const token = await sdk.createSessionToken(openId, { name });
  ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
}

export type AppRouter = typeof appRouter;
