import type { Express, Request, Response, NextFunction } from "express";

const WINDOW_MS = 60_000;
const MAX_REQUESTS = 120;
const MAX_AUTH_REQUESTS = 30;
const requestBuckets = new Map<string, { startedAt: number; count: number }>();

function clientKey(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  const value = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
  return (value || req.socket.remoteAddress || "unknown").trim();
}

function rateLimit(req: Request, res: Response, next: NextFunction) {
  const now = Date.now();
  const key = `${req.path.startsWith("/auth") ? "auth" : "api"}:${clientKey(req)}`;
  const limit = req.path.startsWith("/auth") ? MAX_AUTH_REQUESTS : MAX_REQUESTS;
  const previous = requestBuckets.get(key);
  const bucket = !previous || now - previous.startedAt >= WINDOW_MS
    ? { startedAt: now, count: 1 }
    : { startedAt: previous.startedAt, count: previous.count + 1 };
  requestBuckets.set(key, bucket);
  if (requestBuckets.size > 5000) {
    requestBuckets.forEach((item, bucketKey) => {
      if (now - item.startedAt >= WINDOW_MS) requestBuckets.delete(bucketKey);
    });
  }
  res.setHeader("X-RateLimit-Limit", String(limit));
  if (bucket.count > limit) {
    const retryAfter = Math.max(1, Math.ceil((WINDOW_MS - (now - bucket.startedAt)) / 1000));
    res.setHeader("Retry-After", String(retryAfter));
    res.status(429).json({ error: "طلبات كثيرة. حاول مرة أخرى بعد قليل." });
    return;
  }
  next();
}

export function applySecurity(app: Express) {
  app.disable("x-powered-by");
  app.use("/api", (req, res, next) => {
    const origin = req.headers.origin;
    const allowed = !origin || origin === "capacitor://localhost" || origin === "http://localhost" || origin === "https://localhost" || origin.endsWith(".manus.space") || origin.endsWith(".manus.computer");
    if (!allowed) return res.status(403).json({ error: "مصدر الطلب غير مسموح." });
    if (origin) res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    if (process.env.NODE_ENV === "production") {
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    next();
  });
  app.use("/api/trpc", rateLimit);
}

export function resetRateLimitForTests() {
  requestBuckets.clear();
}
