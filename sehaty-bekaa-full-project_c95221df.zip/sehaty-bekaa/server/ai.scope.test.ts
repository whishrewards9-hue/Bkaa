import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  return {
    user: { id: 9, openId: "ai-scope-test", email: null, name: "اختبار", loginMethod: "phone", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("assistant scope", () => {
  it("keeps unrelated questions outside the directory scope", async () => {
    const caller = appRouter.createCaller(context());
    const result = await caller.ai.chat({ messages: [{ role: "user", content: "اكتب لي قصيدة عن السفر" }] });
    expect(result.answer).toContain("دليل الأطباء والمستشفيات");
  });
});
