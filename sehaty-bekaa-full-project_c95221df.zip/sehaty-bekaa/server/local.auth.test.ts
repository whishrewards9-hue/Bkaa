import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { cookie: () => undefined, clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("local authentication", () => {
  it("rejects an invalid admin password before creating a session", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.auth.local.loginAdmin({ accessCode: "not-the-admin-code" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires a strong patient password during registration", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.auth.local.registerPatient({ fullName: "مريض تجريبي", phone: "03123456", password: "123", gender: "unspecified" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
