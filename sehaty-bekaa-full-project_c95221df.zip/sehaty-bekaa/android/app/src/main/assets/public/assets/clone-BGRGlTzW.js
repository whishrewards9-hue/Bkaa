import{b as r}from"./_baseUniq-BQjJa0ai.js";var e=4;function a(o){return r(o,e)}export{a as c};
