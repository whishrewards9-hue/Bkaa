package com.sehatybekaa.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
