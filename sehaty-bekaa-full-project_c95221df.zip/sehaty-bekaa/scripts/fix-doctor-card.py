from pathlib import Path
p=Path('/home/ubuntu/sehaty-bekaa/client/src/pages/Home.tsx')
s=p.read_text()
old='<button key={doctor.id} onClick={() => onDoctor(doctor.id)} className={`action-card rounded-[1.35rem] border bg-white p-5 text-right ${selectedDoctor === doctor.id ? "border-[#168a75] ring-2 ring-[#b4e3d7]" : "border-[#dfefeb]"}`}> '
if old in s:
    new='<article key={doctor.id} role="button" tabIndex={0} onClick={() => onDoctor(doctor.id)} onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onDoctor(doctor.id); } }} className={`action-card rounded-[1.35rem] border bg-white p-5 text-right ${selectedDoctor === doctor.id ? "border-[#168a75] ring-2 ring-[#b4e3d7]" : "border-[#dfefeb]"}> '
    s=s.replace(old,new,1)
else:
    old='<button key={doctor.id} onClick={() => onDoctor(doctor.id)} className={`action-card rounded-[1.35rem] border bg-white p-5 text-right ${selectedDoctor === doctor.id ? "border-[#168a75] ring-2 ring-[#b4e3d7]" : "border-[#dfefeb]"}`}> '
    if old not in s: raise SystemExit('doctor card opening not found')
    s=s.replace(old, old.replace('<button','<article role="button" tabIndex={0}').replace('> ', '> '),1)
needle='</p></article>)}</div> : <EmptyState icon={Stethoscope}'
if needle not in s:
    needle='</p></button>)}</div> : <EmptyState icon={Stethoscope}'
    if needle not in s: raise SystemExit('doctor card closing not found')
    s=s.replace(needle, '</p></article>)}</div> : <EmptyState icon={Stethoscope}', 1)
p.write_text(s)
