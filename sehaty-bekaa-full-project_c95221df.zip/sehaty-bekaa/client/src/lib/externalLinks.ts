import { Browser } from "@capacitor/browser";
import { Capacitor } from "@capacitor/core";

export type ExternalApp = "whatsapp" | "facebook";

export const WHATSAPP_URL = "https://api.whatsapp.com/send?phone=96171696103&text=" + encodeURIComponent("مرحباً، أحتاج إلى مساعدة في منصة صحتي البقاع.");
export const FACEBOOK_URL = "https://www.facebook.com/share/196oJ9ZNKw/";

function isAndroid() {
  return typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
}

function intentUrl(url: string, app: ExternalApp) {
  if (app === "whatsapp") {
    const parsed = new URL(url);
    return `intent://send?${parsed.searchParams.toString()}#Intent;scheme=whatsapp;package=com.whatsapp;end`;
  }
  return `intent://www.facebook.com/share/196oJ9ZNKw/#Intent;scheme=https;package=com.facebook.katana;end`;
}

export function openExternalLink(event: React.MouseEvent<HTMLAnchorElement>, url: string, app?: ExternalApp) {
  event.preventDefault();
  if (typeof window === "undefined") return;

  if (Capacitor.isNativePlatform()) {
    void Browser.open({ url });
    return;
  }

  if (app && isAndroid()) {
    const fallbackTimer = window.setTimeout(() => {
      window.location.assign(url);
    }, 900);
    const cancelFallback = () => {
      window.clearTimeout(fallbackTimer);
      document.removeEventListener("visibilitychange", cancelFallback);
    };
    document.addEventListener("visibilitychange", cancelFallback, { once: true });
    window.location.href = intentUrl(url, app);
    return;
  }

  const opened = window.open(url, "_blank", "noopener,noreferrer");
  if (!opened) window.location.assign(url);
}
