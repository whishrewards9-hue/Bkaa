import { afterEach, describe, expect, it, vi } from "vitest";
import { FACEBOOK_URL, WHATSAPP_URL, openExternalLink } from "./externalLinks";

describe("external links", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("opens WhatsApp in a new browser/app-capable context on non-Android devices", () => {
    const open = vi.fn(() => ({}));
    vi.stubGlobal("navigator", { userAgent: "Mozilla/5.0 (iPhone)" });
    vi.stubGlobal("window", { open, location: { assign: vi.fn() } });
    const event = { preventDefault: vi.fn() } as never;

    openExternalLink(event, WHATSAPP_URL, "whatsapp");

    expect(event.preventDefault).toHaveBeenCalledOnce();
    expect(open).toHaveBeenCalledWith(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  });

  it("keeps the official Facebook URL as the universal fallback", () => {
    expect(FACEBOOK_URL).toBe("https://www.facebook.com/share/196oJ9ZNKw/");
  });
});
