import { afterEach, describe, expect, it, vi } from "vitest";
import { requestBrowserNotificationPermission, showBrowserNotification } from "./browserNotifications";

describe("browser notifications", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("uses ServiceWorkerRegistration.showNotification without constructing Notification", async () => {
    const showNotification = vi.fn().mockResolvedValue(undefined);
    vi.stubGlobal("window", {
      Notification: { permission: "granted" },
    });
    vi.stubGlobal("navigator", {
      serviceWorker: { ready: Promise.resolve({ showNotification }) },
    });

    await showBrowserNotification("عنوان", "نص الإشعار");

    expect(showNotification).toHaveBeenCalledWith("عنوان", {
      body: "نص الإشعار",
      icon: "/favicon.ico",
      tag: "sehaty-bekaa-update",
    });
  });

  it("does not throw when notification permission is denied", async () => {
    vi.stubGlobal("window", {
      Notification: { permission: "denied" },
    });
    vi.stubGlobal("navigator", {
      serviceWorker: { ready: Promise.resolve({ showNotification: vi.fn() }) },
    });

    await expect(showBrowserNotification("عنوان", "نص")).resolves.toBeUndefined();
  });

  it("requests permission only when it is still undecided", () => {
    const requestPermission = vi.fn().mockResolvedValue("granted");
    vi.stubGlobal("window", {
      Notification: { permission: "default", requestPermission },
    });

    requestBrowserNotificationPermission();

    expect(requestPermission).toHaveBeenCalledOnce();
  });
});
