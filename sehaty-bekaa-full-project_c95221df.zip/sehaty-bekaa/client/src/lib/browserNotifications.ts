export async function showBrowserNotification(title: string, body: string) {
  if (typeof window === "undefined" || !("Notification" in window)) return;

  try {
    const notificationApi = window.Notification;
    if (notificationApi.permission !== "granted") return;
    if (!("serviceWorker" in navigator)) return;

    const registration = await navigator.serviceWorker.ready;
    await registration.showNotification(title, {
      body,
      icon: "/favicon.ico",
      tag: "sehaty-bekaa-update",
    });
  } catch {
    // الإشعار اختياري ولا يجوز أن يعطّل تسجيل الدخول أو عمل المنصة.
  }
}

export function requestBrowserNotificationPermission() {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (window.Notification.permission !== "default") return;
  void window.Notification.requestPermission().catch(() => undefined);
}
