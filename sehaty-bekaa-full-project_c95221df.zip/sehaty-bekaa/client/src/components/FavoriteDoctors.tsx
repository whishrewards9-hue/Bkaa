import { CalendarCheck, Heart, Phone, Stethoscope } from "lucide-react";

type FavoriteDoctor = {
  doctorId: number;
  fullName: string;
  phone: string;
  specialtyName: string;
  hospitalName: string | null;
  hospitalDefaultName?: string | null;
  clinicAddress?: string | null;
  clinicLocationUrl?: string | null;
  photoUrl?: string | null;
  scheduleStart: string;
  scheduleEnd: string;
  active: boolean;
};

export function FavoriteDoctors({ doctors, onRemove, onSelect }: { doctors: FavoriteDoctor[]; onRemove: (doctorId: number) => void; onSelect: (doctorId: number) => void }) {
  return <section className="rise-in">
    <div className="mb-6 flex items-end justify-between gap-3">
      <div><p className="mb-2 text-xs font-bold tracking-[.18em] text-[#168a75]">قائمة الوصول السريع</p><h2 className="text-2xl font-extrabold tracking-tight text-[#153e3a] sm:text-3xl">الأطباء المفضلون</h2><p className="mt-2 text-sm leading-7 text-[#637b78]">احفظ طبيبك المفضل للعودة إليه وحجز موعد بسهولة.</p></div><Heart className="hidden text-[#e75662] sm:block" size={30} fill="currentColor" />
    </div>
    {doctors.length ? <div className="grid gap-4 md:grid-cols-2">{doctors.map(doctor => <article key={doctor.doctorId} className="soft-card rounded-[1.4rem] bg-white p-5"><div className="flex items-start justify-between gap-3"><div className="flex items-center gap-3"><span className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-full border-2 border-[#d8eee8] bg-[#e5f5f0] text-[#168a75]">{doctor.photoUrl ? <img src={doctor.photoUrl} alt={doctor.fullName} className="h-full w-full object-cover"/> : <Stethoscope size={21}/>}</span><div><h3 className="text-sm font-extrabold text-[#254f49]">{doctor.fullName}</h3><p className="mt-1 text-[11px] font-bold text-[#168a75]">{doctor.specialtyName}</p></div></div><button type="button" onClick={() => onRemove(doctor.doctorId)} aria-label={`إزالة ${doctor.fullName} من الأطباء المفضلين`} title="إزالة من المفضلة" className="rounded-xl p-2 text-[#e75662] transition hover:bg-[#fff0f1]"><Heart size={20} fill="currentColor"/></button></div><p className="mt-4 text-[10px] text-[#77918d]">{doctor.hospitalName || doctor.hospitalDefaultName || "عيادة خاصة"}{doctor.clinicAddress ? ` • ${doctor.clinicAddress}` : ""} • الدوام {doctor.scheduleStart} — {doctor.scheduleEnd}</p>{doctor.clinicLocationUrl && <a href={doctor.clinicLocationUrl} target="_blank" rel="noreferrer" className="mt-2 inline-block text-[10px] font-bold text-[#168a75]">عرض موقع العيادة</a>}<div className="mt-4 flex flex-wrap gap-2 border-t border-[#e4f0ed] pt-3"><button type="button" onClick={() => onSelect(doctor.doctorId)} className="inline-flex items-center gap-2 rounded-xl bg-[#168a75] px-3 py-2.5 text-[10px] font-bold text-white"><CalendarCheck size={14}/> حجز موعد</button><a href={`tel:${doctor.phone}`} className="inline-flex items-center gap-2 rounded-xl bg-[#f2f8f6] px-3 py-2.5 text-[10px] font-bold text-[#287565]"><Phone size={14}/> {doctor.phone}</a></div></article>)}</div> : <div className="rounded-[1.4rem] border border-dashed border-[#b5d8d0] bg-white/70 px-6 py-14 text-center"><Heart className="mx-auto text-[#e5a5aa]" size={30}/><h3 className="mt-4 font-bold text-[#244b47]">لم تحفظ أي طبيب بعد</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#6d8582]">اضغط على رمز القلب في بطاقة الطبيب أثناء الحجز ليظهر هنا.</p></div>}
  </section>;
}
