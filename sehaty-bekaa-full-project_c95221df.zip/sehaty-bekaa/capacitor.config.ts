import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sehatybekaa.app',
  appName: 'صحتي البقاع',
  webDir: 'dist/public',
  plugins: {
    SplashScreen: {
      launchAutoHide: true,
      launchShowDuration: 900,
      backgroundColor: '#f4fbf8',
      showSpinner: false
    },
    StatusBar: {
      backgroundColor: '#168a75',
      style: 'LIGHT'
    },
    Keyboard: {
      resize: 'body'
    }
  }
};

export default config;
